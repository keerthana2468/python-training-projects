#!/usr/bin/env bash
python src/automation/log_parser.py sample.log
python -c "from src.tools.pattern_printer import print_triangle; print_triangle(4)"
