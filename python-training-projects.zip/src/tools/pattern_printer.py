# src/tools/pattern_printer.py
def print_triangle(n: int):
    for i in range(1, n + 1):
        print('*' * i)

if __name__ == "__main__":
    print_triangle(5)
