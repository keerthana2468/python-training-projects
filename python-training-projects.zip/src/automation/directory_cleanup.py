# src/automation/directory_cleanup.py
from pathlib import Path
from typing import List

def cleanup_folder(folder: str, extension: str = ".tmp") -> List[str]:
    """Delete files with given extension in folder (non-recursive)."""
    p = Path(folder)
    if not p.is_dir():
        raise NotADirectoryError(f"{folder} is not a directory")
    removed = []
    for f in p.iterdir():
        if f.is_file() and f.suffix == extension:
            f.unlink()
            removed.append(f.name)
    return removed

if __name__ == "__main__":
    import sys
    folder = sys.argv[1] if len(sys.argv) > 1 else "."
    print(cleanup_folder(folder))
