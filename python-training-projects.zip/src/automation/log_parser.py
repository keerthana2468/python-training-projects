# src/automation/log_parser.py
import re
from pathlib import Path
from typing import List

def parse_errors(log_path: str) -> List[str]:
    """Return lines that contain 'ERROR' from a log file."""
    path = Path(log_path)
    if not path.exists():
        raise FileNotFoundError(f"{log_path} not found")

    errors = []
    pattern = re.compile(r'ERROR', re.IGNORECASE)
    with path.open() as f:
        for line in f:
            if pattern.search(line):
                errors.append(line.strip())
    return errors

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python src/automation/log_parser.py <logfile>")
        sys.exit(1)
    for e in parse_errors(sys.argv[1]):
        print(e)
