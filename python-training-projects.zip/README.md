# Python Training Projects — Keerthana Gatla

Collection of small Python projects created during professional training in Python and Linux.
These exercises demonstrate scripting, test-driven development, and basic automation useful for platform engineering roles.

## Projects
- `src/automation/log_parser.py` — extract ERROR lines from logs (CLI)
- `src/automation/directory_cleanup.py` — remove temporary files with given extension
- `src/tools/calculator.py` — basic calculator functions (with tests)
- `src/tools/pattern_printer.py` — prints a simple star triangle

## Quick start
1. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
2. Run examples:
```bash
python src/automation/log_parser.py sample.log
python -c "from src.tools.pattern_printer import print_triangle; print_triangle(4)"
```

## Tests
```bash
pytest -q
```

## About
I come from a Civil Engineering background and completed dedicated training in Python, Linux and DevOps fundamentals. I built these projects to practice automation and platform engineering skills.

## License
MIT
