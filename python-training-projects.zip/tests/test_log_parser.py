# tests/test_log_parser.py
from src.automation.log_parser import parse_errors

def test_parse_errors(tmp_path):
    sample = tmp_path / "sample.log"
    sample.write_text("INFO ok\nERROR oh no\n")
    errors = parse_errors(str(sample))
    assert len(errors) == 1
    assert "ERROR" in errors[0]
